package messages;

public abstract class Message {
}
